let USERNAME_KEY='username.key'

let SELECTED_FOLDER_KEY='selected.id'

let SELECTED_ENTRY_KEY='selected_entry.key'

let userName=localStorage.getItem(USERNAME_KEY) || 'User Name'

let selectedEntry=localStorage.getItem(SELECTED_ENTRY_KEY)

const STORAGE_KEY='journal.entries'

let JOURNAL_ENTRIES=JSON.parse(localStorage.getItem(STORAGE_KEY)) || []

const newUserNameForm=document.querySelector('[data-new-UserName-form]')

const journalNameOnTopBar=document.querySelector('#journal-name')

const deselectEntry=document.querySelector('#typing-affect')
const deleteSelected=document.querySelector('#delete-selected-btn')

const deleteAll=document.querySelector('#delete-all-btn')

const deleteSelectedEntry=document.querySelector('#delete-selected')
let articleTag=document.querySelectorAll('#entry')
const dropDownEdit=document.querySelector('#edit')
let userNameInput=document.querySelector('#new-userName-input')
const dropDownDeleteAll=document.querySelector('#delete-all')
let userNameText=document.querySelector('#username')
const journalFoldersContainer=document.querySelector('.journal-folder')
const typingEffectOpt=document.querySelector('#type-affect')
const textAreaEdit=document.querySelector('#edit-entry')
const EditEntryForm=document.querySelector('[data-edit-entry]')
const folderTemplate=document.querySelector('[data-folder-template]')

const newFolderForm=document.querySelector('[data-new-folder-form]')

const newTaskForm=document.querySelector('[data-entry-form]')

const textArea=document.querySelector('#text-area')

const doneBtn=document.querySelector('#done-btn')

const EntryContainer=document.querySelector('.entry-container');

const entryTemplate=document.querySelector('#entry-template')

const newFolderInput=document.querySelector('#new-folder-input')

const Title_of_entry=document.querySelector('#title-entry')

const FolderContainer=document.querySelector('.journal-folder')

let selectedJournalFolder=localStorage.getItem(SELECTED_FOLDER_KEY)



let todaysDate=document.querySelector('.todays-date')
//date management
var  d = new Date().getDay()
var Td=new Date().getDate()
var mon=new Date().getMonth()+1

var day;
var TodayDate=Td
if (d==1) {
  day = 'Monday'
}
else if(d==2){
  day='Tuesday'
}
else if(d==3){
  day='Wednesday'
}
else if(d==4){
  day='Thursday'
}
else if(d==5){
  day='Friday'
}
else if(d==6){
  day='Saturday'
}
else{
  day='Sunday'
}

let Month;
switch (mon) {
    case 1:
   Month='January';
   break;
   
case 2:
  Month='February'
  break;
  
  case 3:
    Month='March'
    break;
    
    case 4:
      Month='April'
      break;
      
      case 5:
       Month='May' 
       break;
       
       case 6:
         Month='June'
         break;
        
        case 7:
          Month='July'
            case 1:
   break;
   
case 8:
  Month='August'
  break;
  
  case 9:
    Month='September'
    break;
    
    case 10:
      Month='October'
      break;
      
      case 11:
       Month='November' 
       break;
       
         default:
         Month='December'
         break;
        
}
 todaysDate.innerText=`${day} , ${TodayDate} ${Month}`

//date management ends here 

/*
opacity when scroling
*/
let btn=document.querySelector('.new-folder-btn')
 let navigation=document.querySelector('#nav')
EntryContainer.addEventListener('touchstart',()=>{
 btn.style.opacity='50%'
 btn.innerText=''
 navigation.style.opacity='50%'

})
EntryContainer.addEventListener('touchmove',()=>{
 btn.style.opacity='4%'
 navigation.style.opacity='4%'

})
EntryContainer.addEventListener('touchend',()=>{
 setTimeout(()=>{
 btn.style.opacity='100%'
 btn.innerHTML=`<a class="uk-animation-scale-down" href="#modal-center" uk-icon="plus" uk-toggle>new folder</a>
`
 navigation.style.opacity='100%'
},2000)
})

FolderContainer.addEventListener('click',e=>{
 if(e.target.tagName.toLowerCase()==='div'){

selectedJournalFolder=e.target.dataset.folderId

saveAndRender()
 }
})


//dropdown functions 

//1. edit 
dropDownEdit.addEventListener('click',(e)=>{
 e.preventDefault()

let currentFolder=JOURNAL_ENTRIES.find(entry=>entry.id===selectedJournalFolder)

let currentEntry=currentFolder.entries.find(entry=>entry.id==selectedEntry)

textAreaEdit.value=currentEntry.content


})

EditEntryForm.addEventListener('submit',()=>{

 
 
 let currentFolder=JOURNAL_ENTRIES.find(entry=>entry.id===selectedJournalFolder)

let currentEntry=currentFolder.entries.find(entry=>entry.id==selectedEntry)

currentEntry.content=textAreaEdit.value



saveAndRender()

})
//edit end here 


//2. delete selected
deleteSelectedEntry.addEventListener('click',(e)=>{
 e.preventDefault()

let decision=confirm('do you realy want to delete your current selected entry')

if(!decision){
 return
}

else{
let currentFolder=JOURNAL_ENTRIES.find(folder=>folder.id===selectedJournalFolder) 

 currentFolder.entries=currentFolder.entries.filter(entry=>entry.id!=selectedEntry)
notification('success👍', 'success')
 saveAndRender()
}
})
//delete selected function ends here 

//3. 

//delete all from dropdown starts here

dropDownDeleteAll.addEventListener('click',()=>{
 
let decision=confirm('do you realy want to DELETE ALL OF YOUR ENTRIES')

if(!decision){
 return
}

else{
 let currentFolder=JOURNAL_ENTRIES.find(entry=>entry.id==selectedJournalFolder)
 
 currentFolder.entries.length=0
 notification('success👍','success')
 saveAndRender()
}
})
//delete all ends here

//4.

//deselect an entry 
deselectEntry.addEventListener('click',()=>{
 Array.from(articleTag).forEach(article=>{
  article.classList.remove('active-entry')
 })
 selectedEntry=null
 saveAndRender()
})
//deselects ends here 

//5. typing affect 

typingEffectOpt.addEventListener('click',(e)=>{
 e.preventDefault()
 if(selectedEntry===null){
  notification('first tap on an entry to select it')
  return
 }
 let articleTag=document.querySelector('.active-entry')

 let articleContent=articleTag.querySelector('#entry-content')
 
 let p=articleContent.querySelector('p')
 let i=0
 let text=articleContent.textContent
articleContent.innerText=''
 let speed=120
 
 function start(){
  if(i<text.length){
   articleContent.textContent+=text.charAt(i)
   i++
   setTimeout(start,speed)
   navigation.style.opacity='0%'
   btn.style.opacity='0%'
  }
  else{
   navigation.style.opacity='100%'
   btn.style.opacity='100%'

  }
  
 }
 start()
})
//typing affect ends here 

newUserNameForm.addEventListener('submit',e=>{
 e.preventDefault()
 notification('success👍','success')
  userNameText.textContent=userNameInput.value
 
 userName=userNameInput.value.trim()
 userNameInput.value=''
save()
})

newFolderForm.addEventListener('submit',e=>{
 e.preventDefault()

 let newFolder=createFolder(newFolderInput.value)
 JOURNAL_ENTRIES.unshift(newFolder)
 newFolderInput.value=''
 
notification('successfully added a new folder👍','success')

 saveAndRender()
})

textArea.addEventListener('keyup',()=>{
 navigation.style.opacity='10%'
})
textArea.addEventListener('blur',()=>{
 navigation.style.opacity='100%'
})

newTaskForm.addEventListener('submit',e=>{
 e.preventDefault()
 let hours=new Date().getHours()
let minutes=new Date().getMinutes()

let hrs=hours<=9?`0${hours}`:hours
let min=minutes<=9?`0${minutes}`:minutes
let time=`${hrs}:${min}`

let dAte=`${day} , ${TodayDate} ${Month}`

 let newEntry=createEntry(textArea.value,time,dAte)
 
let currentFolder=JOURNAL_ENTRIES.find(entry=>entry.id===selectedJournalFolder)


currentFolder.entries.unshift(newEntry)

textArea.value=''
notification('new entry submitted successfully 👍','success')
saveAndRender()
})
deleteAll.addEventListener('click',()=>{
 JOURNAL_ENTRIES.length=0
 saveAndRender()
})
deleteSelected.addEventListener('click',()=>{
JOURNAL_ENTRIES=JOURNAL_ENTRIES.filter(entry=>entry.id!==selectedJournalFolder)
selectedJournalFolder=null
 saveAndRender()
})

function createFolder(name){
 return {name:name,id:Date.now().toString(),entries:[]}
}
function createEntry(name,time,date){
 return {content:name,id:Date.now().toString(),time:time.toString(),date:date.toString()}
}


function render(){
 clearElement(FolderContainer)
renderFolders()
 if(selectedJournalFolder===null){
  return
  
 }
 else{
 let currentFolder=JOURNAL_ENTRIES.find(entry=>entry.id===selectedJournalFolder)
renderEntryCount(currentFolder)
let entryName=document.querySelector('#journal-name')
entryName.innerText=currentFolder.name
renderEntries(currentFolder)
 }
}


function renderEntries(currentFolder){
clearElement(EntryContainer)

currentFolder.entries.forEach(entry=>{
 
 let template=document.importNode(entryTemplate.content,true)
 
 let article=template.querySelector('#entry')
 
 let author=template.querySelector('.author')
 author.innerText=userName
 
 let date=template.querySelector('.date')



let datePosted=template.querySelector('#time-posted')

date.innerText=entry.date

datePosted.innerText=entry.time

 let entryContent=template.querySelector('#entry-content')
 
 article.dataset.entryId=entry.id
 
 entryContent.innerText=entry.content
 
 if(entry.id===selectedEntry){
  article.classList.add('active-entry')
 }
 
 EntryContainer.appendChild(template)
 
})

}
EntryContainer.addEventListener('click',e=>{
 if(e.target.tagName.toLowerCase()==='article'){
  
   selectedEntry=e.target.dataset.entryId
   saveAndRender()
  
  }
})

function renderFolders(){
JOURNAL_ENTRIES.forEach(entry=>{
 let template=document.importNode(folderTemplate.content,true)
 
 let span=template.querySelector('.folder-text')
  span.innerText=entry.name

 let folderDiv=template.querySelector('.folder')
 
 folderDiv.dataset.folderId=entry.id
 
 if(entry.id===selectedJournalFolder){
  folderDiv.classList.add('active')
 }
 
 FolderContainer.appendChild(template)
})


}
function renderEntryCount(currentFolder){
 let entryLength=currentFolder.entries.length
 let count=document.querySelectorAll('#count')
 let countString=entryLength==1?"entry" : "entries";
 Array.from(count).forEach(c=>{
 c.innerText=`${entryLength} ${countString}`
 })


}

function clearElement(element){
 while(element.firstChild){
  element.removeChild(element.firstChild)
 }
}
function showUserName(){
userNameText.innerText=userName || 'User Name'
}
function notification(message,status){
 UIkit.notification({
  message:message,
  status:status,
  pos:'top-left',
  timeout:1500
 })
}
function saveAndRender(){
 save()
 render()
}
function save(){
localStorage.setItem(USERNAME_KEY,userName)
 
localStorage.setItem(STORAGE_KEY,JSON.stringify(JOURNAL_ENTRIES))
 localStorage.setItem(SELECTED_FOLDER_KEY,selectedJournalFolder)
 localStorage.setItem(SELECTED_ENTRY_KEY,selectedEntry)
}
saveAndRender()
showUserName()
//mission well done Lovejoy


//don't wipe out the local storage no matter what happens 

//the year 2022 is on this website



